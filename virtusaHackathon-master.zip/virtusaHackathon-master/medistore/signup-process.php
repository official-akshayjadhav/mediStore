<?php
    session_start();
    include 'db.php';
    /* Registration process, inserts user info into the database 
       and sends account confirmation email message
     */
    
    // Escape all $_POST and SESSION variables to protect against SQL injections
    $Name = $_POST['name'];
    $Email = $_POST['email'];
    $Password = $_POST['password'];
    $Address = $_POST['address'];
    $Telephone = $_POST['telephone'];
    // Check if user with that email already exists in respective tables
  
    $result = $mysqli->query("SELECT * FROM loginTable WHERE Username='$email'") or die($mysqli->error());
    
    // We know user email exists if the rows returned are more than 0
    if ( $result->num_rows > 0 ) {
        
        $_SESSION['message'] = 'User with this email already exists!';
        echo $_SESSION['message'];
        header("location: error.php");
        
    }
    else { // Email doesn't already exist in a database, proceed...
    
        // active is 0 by DEFAULT (no need to include it here)
        $sql = "INSERT INTO loginTable (Username, Password, Name, Address, Phone) VALUES ('$Email', '$Password', '$Name', '$Address', $Telephone)";

        // Add user to the database
        if ($mysqli->query($sql)){
    
            $_SESSION['message']= "user added successfully";
            header("location: success.php"); 
        }
    
        else {
            echo "Error: " . $sql . "<br>" . $mysqli->error;
            $_SESSION['message'] = 'Registration failed!';
            header("location: error.php");
        }
    }
?>