<?php
/* User login process, checks if user exists and password is correct */
session_start();
include 'db.php';

// Escape email to protect against SQL injections
$email = $_POST['email'];
// echo $email;

$result = $mysqli->query("SELECT UID, Password, Name FROM loginTable where Username = '$email';");

if ( $result->num_rows == 0 ){ // User doesn't exist
    // echo "User with that email doesn't exist!";
}
else { // User exists

    $user = $result->fetch_assoc();

    if (strcmp($_POST['input-password'], $user['Password'])==0) {
      
        $_SESSION['UID'] = $user['UID'];
        $_SESSION['email'] = $email;
        $_SESSION['name'] = $user['Name'];
       
        // This is how we'll know the user is logged in
        $_SESSION['logged_in'] = 1;
        
        header("location: home.php"); //it goes to homepage
    }
    else {
       
    }
}

?>