<?php
    if(isset($_GET['feedback'])){
        unset($_GET['feedback']);
        echo '<script> alert("prescription uploaded successfully") </script>';
    }
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1"/>
        <link rel="icon" href="images/favicon.png"/>
        <title>5Medi</title>
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
        <link rel="stylesheet" type="text/css" href="css/style.css"/>
        <link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css"/>
        <link rel="stylesheet" href="css/owl-carousel.css"/>
        <script src="js/jquery.min.js"></script>
        <script src="js/owl-carousel.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/custom.js"></script>
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-sm-4 col-xs-4" id="logo" >
                    <a href="home.php" class="logo-text">
                        5<span style="color:#39BAF0; font-size:40px">Medi</span>
                    </a>
                </div>
                <div class="col-md-2 col-sm-12 col-xs-12" style="display:none " id="navbar_hide" >
                    <nav  role="navigation" class="navbar navbar-inverse">
                        <a href="home.php" style="float: left" class="logo-text">
                            5<span style="color:#39BAF0; font-size:40px">Medi</span>
                        </a>
                        <div id="nav">
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar" style="background: #8EBE08; border: none; margin-right: 0">
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                            </div>
                            <div class="collapse navbar-collapse" id="myNavbar">
                                <ul class="nav navbar-nav site_nav_menu1"  >
                                    <li class="first " ><a href="home.php">Home</a></li>
                                    <li><a href="cart.php">Shipping and Payment</a></li>
                                    <li><a href="medical-services.php">Medical Services</a></li>
                                    <li><a href="about_us.html">About Us</a></li>
                                    <li><a href="contact_us.html">Contact</a></li>
                                </ul>
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
        <div class="container-fluid bg-color">
            <div class="row">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 col-xs-12">
                            <nav  role="navigation" class="navbar navbar-inverse" id="nav_show">
                                <div id="nav">
                                    <div class="navbar-header">
                                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                                            <span class="icon-bar"></span>
                                            <span class="icon-bar"></span>
                                            <span class="icon-bar"></span>
                                        </button>

                                    </div>
                                    <div class="collapse navbar-collapse" id="myNavbar">
                                        <ul class="nav navbar-nav site_nav_menu1"  >
                                            <li class="first "><a href="home.php">Home</a></li>
                                            <li><a href="prescription.php">Upload Prescription</a></li>
                                            <li><a href="cart.php">Shipping and Payment</a></li>
                                            <li><a href="medical-services.php">Medical Services</a></li>
                                            <li><a href="about_us.html">About Us</a></li>
                                            <li><a href="contact_us.html">Contact</a></li>
                                        </ul>

                                    </div>
                                </div>
                            </nav>
                        </div>
                    </div>

                </div>
            </div>
        </div>


        <div class="container"> 
            <div class="container">
              <div class="jumbotron">
                <h1>Upload prescription</h1>
                <p>Upload prescription file image</p>
              </div>
          
            </div>
             <div class="panel panel-default">
                <form action="processPrecription.php" method="post" enctype="multipart/form-data">
                        <div class="panel-heading">Select Image File to Upload:</div>
                        <input type="file" name="file">
                        <br/><br/>
                        <input class="btn btn-primary" type="submit" name="submit" value="Upload">
                </form>
            </div>
        </div>

        <a style="display: none" href="javascript:void(0);" class="scrollTop back-to-top" id="back-to-top">
            <i class="fa fa-chevron-up"></i>
        </a>
    </body>
</html>
