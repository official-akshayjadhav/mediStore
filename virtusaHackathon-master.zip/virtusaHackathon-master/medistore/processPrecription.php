<?php
    session_start();
    include 'db.php';
    
    //Get the content of the image and then add slashes to it 
    // $imagetmp=addslashes (file_get_contents($_FILES['file']['tmp_name']));

    // $q = "INSERT INTO prescription (ID,image,status,tokenNo) VALUES (1,'myimage.jpg', LOAD_FILE('http://icons.iconarchive.com/icons/artua/soccer/512/football-icon.png',1,2));"; 
    // $result = $mysqli->query($q);
    // if($result){
    //     echo 'File Uploaded !';
    // }else{
    //     echo 'File not uplaoded !';  
    //     echo mysqli_errno($this->db_link);
    // }

    $statusMsg = '';
    
    // File upload path
    $targetDir = "uploads/";
    $fileName = basename($_FILES["file"]["name"]);
    $targetFilePath = $targetDir . $fileName;
    $fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);
    
    if(isset($_POST["submit"]) && !empty($_FILES["file"]["name"])){
        // Allow certain file formats
        $allowTypes = array('jpg','png','jpeg','gif','pdf');
        if(in_array($fileType, $allowTypes)){
            // Upload file to server
            if(move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath)){
                // Insert image file name into database
                $uid = $_SESSION['UID'];
                $insert = $mysqli->query("INSERT into prescriptions(UID, image, status, tokenNo) VALUES (1, '".$fileName."', 1, 1);");
                if($insert){
                    $statusMsg = "The file ".$fileName. " has been uploaded successfully.";
                }else{
                    $statusMsg = "File upload failed, please try again.";
                } 
            }else{
                $statusMsg = "Sorry, there was an error uploading your file.";
            }
        }else{
            $statusMsg = 'Sorry, only JPG, JPEG, PNG, GIF, & PDF files are allowed to upload.';
        }
    }else{
        $statusMsg = 'Please select a file to upload.';
    }
    
    header('location: prescription.php?feedback=1')
?>
