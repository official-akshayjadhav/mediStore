<?php
    if(isset($_GET['mail'])){
        unset($_GET['mail']);
        $to = "rohithamster@gmail.com";
        $subject = "from 5medi, regarding to medicine prescription.";
        $txt = "your prescription is received & verified, our team will try to contact you soon. status details";
        $headers = "From: rohitsa40@gmail.com" . "\r\n" .
        "CC: rohithamster@gmail.com";
        
        mail($to,$subject,$txt,$headers);
        echo "<script> alert('email successfully sent!');</script>";
    }
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1"/>
        <link rel="icon" href="images/favicon.png"/>
        <title>5Medi</title>
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
        <link rel="stylesheet" type="text/css" href="css/style.css"/>
        <link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css"/>
        <link rel="stylesheet" href="css/owl-carousel.css"/>
        <script src="js/jquery.min.js"></script>
        <script src="js/owl-carousel.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/custom.js"></script>
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-sm-4 col-xs-4" id="logo" >
                    <a href="home.html" class="logo-text">
                        5<span style="color:#39BAF0; font-size:40px">Medi</span>
                    </a>
                </div>
                <div class="col-md-2 col-sm-12 col-xs-12" style="display:none " id="navbar_hide" >
                    <nav  role="navigation" class="navbar navbar-inverse">
                        <a href="home.html" style="float: left" class="logo-text">
                            5<span style="color:#39BAF0; font-size:40px">Medi</span>
                        </a>
                        <div id="nav">
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar" style="background: #8EBE08; border: none; margin-right: 0">
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                            </div>
                            <div class="collapse navbar-collapse" id="myNavbar">
                                <ul class="nav navbar-nav site_nav_menu1"  >
                                    <li class="first " ><a href="home.php">Home</a></li>
                                    <li><a href="cart.php">Shipping and Payment</a></li>
                                    <li><a href="medical-services.php">Medical Services</a></li>
                                    <li><a href="about_us.html">About Us</a></li>
                                    <li><a href="contact_us.html">Contact</a></li>
                                </ul>
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
        <div class="container-fluid bg-color">
            <div class="row">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 col-xs-12">
                            <nav  role="navigation" class="navbar navbar-inverse" id="nav_show">
                                <div id="nav">
                                    <div class="navbar-header">
                                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                                            <span class="icon-bar"></span>
                                            <span class="icon-bar"></span>
                                            <span class="icon-bar"></span>
                                        </button>

                                    </div>
                                    <div class="collapse navbar-collapse" id="myNavbar">
                                        <ul class="nav navbar-nav site_nav_menu1"  >
                                            <li class="first "><a href="home.php">Home</a></li>
                                            <li><a href="prescription.php">Upload Prescription</a></li>
                                            <li><a href="cart.php">Shipping and Payment</a></li>
                                            <li><a href="medical-services.php">Medical Services</a></li>
                                            <li><a href="about_us.html">About Us</a></li>
                                            <li><a href="contact_us.html">Contact</a></li>
                                        </ul>

                                    </div>
                                </div>
                            </nav>
                        </div>
                    </div>

                </div>
            </div>
        </div>

         <h2> Admin Panel : prescription table</h2>
         
        <div>
            <table class="table table-bordered">
            <tr>
                <th> User id </th>
                <th> prescription </th>
                <th> status </th>
                <th> All med. Available </th>
                <th> Flaged prescription </th>
                <th> mail </th>
                
            </tr>
           <?php
                // Include the database configuration file
                include 'db.php';
                
                // Get images from the database
                $query = $mysqli->query("SELECT UID, image, status FROM prescriptions");
                
                if($query->num_rows > 0){
                    while($row = $query->fetch_row()){
                         
                        $imageURL = 'uploads/'.$row[1];
                        
                ?>
                
                    
                    <tr>
                        <td>
                            <?php echo $row[0]; ?>
                        </td>
                        &nbsp;&nbsp;&nbsp;
                        <td>
                            <img src="<?php echo $imageURL; ?>" alt="" width="200" height="300"/>
                        </td>
                        &nbsp;&nbsp;&nbsp;
                        <td>
                            <h3><?php echo $row[2] ?><h3/>
                        </td>
                        <td>
                            <input type="checkbox"/>
                        </td>
                        <td>
                            <input type="checkbox"/>
                        </td>
                         <td>
                            <form action="viewPrescription.php?mail=1">
                                <input type="hidden" name="mail" value="1" />
                                <input class="btn btn-primary" type="submit" value="Send Mail"/>
                            </form>
                        </td>
                    </tr>
                
                    <br/>
                <?php }
                }else{ ?>
                    <p>No image(s) found...</p>
                <?php } 
            ?>
        </table>
        </div>


       
        <a style="display: none" href="javascript:void(0);" class="scrollTop back-to-top" id="back-to-top">
            <i class="fa fa-chevron-up"></i>
        </a>
    </body>
</html>
