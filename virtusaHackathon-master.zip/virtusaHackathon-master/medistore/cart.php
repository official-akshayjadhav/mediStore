<?php
    session_start();
    
    if(!isset($_SESSION['UID'])){
        echo '<script> alert("please log in to see this page "); </script>';
        echo' <script>window.location.replace("home.php"); </script>';
    }

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1"/>
        <link rel="icon" href="images/favicon.png"/>
        <title>5 Medi</title>
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
        <link rel="stylesheet" type="text/css" href="css/style.css"/> 
        <link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css"/>
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/custom.js"></script>
        
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-sm-4 col-xs-4" id="logo" >
                    <a href="home.php" class="logo-text">
                        5 <span style="color:#39BAF0; font-size:40px">Medi</span>
                    </a>		
                </div>
                <div class="col-md-2 col-sm-12 col-xs-12" style="display:none " id="navbar_hide" >
                    <nav  role="navigation" class="navbar navbar-inverse">
                        <a href="home.php" style="float: left" class="logo-text">
                            5 <span style="color:#39BAF0; font-size:40px">Medi</span>
                        </a>
                        <div id="nav">
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar" style="background: #8EBE08; border: none; margin-right: 0">
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                            </div>
                            <div class="collapse navbar-collapse" id="myNavbar">
                                <ul class="nav navbar-nav site_nav_menu1"  >
                                    <li class="first " ><a href="home.php">Home</a></li>
                                    <li><a href="cart.php">Shipping & Payment</a></li>
                                    <li><a href="about_us.html">About us</a></li>
                                    <li><a href="contact_us.html">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                    </nav>
                </div>
                <div class="col-md-4 col-md-offset-4 col-sm-offset-2  col-sm-6 col-xs-12" >
                    <div id="top_right">
                        <div id="cart">
                            <div class="text">
                                <div class="img">
                                    <a href="cart.html"> <img class="img-responsive" src="images/cart.png" alt="" title="" width="26" height="27" /></a>
                                </div>
                            </div> 
                        </div>
                        <div id="bottom_right">
                            <div class="row">
                                <div class="col-md-6 col-xs-6 wd_auto">
                                    <div class="left">
                                        <div class="login">
                                            <a class="btn btn-default reg_button" href="login.html">Login</a> 
                                            <a class="btn btn-default reg_button" href="register.html">Signup</a>
                                                </div>			
                                    </div>
                                </div> 
                                <div class="dropdown-bn wd-33 col-md-6 remove_PL col-xs-6">
                                    <div class="row">
                                        <div class="pl-0 col-md-6 col-xs-6">

                                           </div>

                                        </div>

                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            
        </div> 
        
        <div class="container-fluid ">
            <div class="row">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 col-xs-12">
                            <nav  role="navigation" class="navbar navbar-inverse" id="nav_show">
                                <div id="nav">
                                    <div class="navbar-header">
                                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                                            <span class="icon-bar"></span>
                                            <span class="icon-bar"></span>
                                            <span class="icon-bar"></span>
                                        </button>

                                    </div>
                                    <div class="collapse navbar-collapse" id="myNavbar">
                                        <ul class="nav navbar-nav site_nav_menu1"  >
                                            <li class="first "><a href="home.php">Home</a></li>
                                            <li><a href="cart.php">Shipping & Payment</a></li>
                                            <li><a href="about_us.html">About us</a></li>
                                            <li><a href="contact_us.html">Contact Us</a></li>
                                        </ul>

                                    </div>
                                </div>
                            </nav>
                        </div>
                    </div> 

                </div>
            </div>

        <div class="main-content">
            <div class="container cart-block-style">          
                <div class="breadcrumbs">
                    <a href="home.php"><i class="fa fa-home"></i></a>
                    <a href="#">Shopping Cart</a>
                </div>
                <div class="contentText">
                    <h1>Shopping Cart                                &nbsp;
                    </h1>
                </div>
                <form>
                    <div class="table-responsive margin-top">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <td class="text-center">image</td>
                                    <td class="text-left">PRODUCT NAME</td>
                                    <td class="text-left">MODEL</td>
                                    <td class="text-left">QUANTITY</td>
                                    <td class="text-right">UNIT PRICE</td>
                                    <td class="text-right">TOTAL</td>
                                        <td class="text-right">DELETE</td>
                                
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                include 'db.php';
                                    $gtotal=0;
                                    if(!isset($_GET['UID'])){
                                        $id = $_SESSION['UID'];
                                    }
                                    else{
                                        $id = $_GET['UID'];
                                    }
                                    
                                    $result = $mysqli->query("SELECT PID,count FROM cart where UID = $id;");
                                    if($result->num_rows >0)
                                    {
                                        while($row=$result->fetch_assoc())
                                        {
                                            $a= $row['PID']; 
                                            $result1 = $mysqli->query("SELECT productId,productName,productPrice,Image FROM productTable where productId =$a;");
                                                
                                          $row1=$result1->fetch_assoc();
                                          $total=$row["count"]*$row1["productPrice"];
                                          $gtotal=$gtotal+$total;
                                            echo "<tr> <td> <img src=".$row1["Image"]." height='125px' width='125px' > </td><td>".$row1["productName"]." </td><td>".$a."</td><td>".$row["count"]."</td><td>".$row1['productPrice']. "</td><td>".$total."</td></tr>" ;
                                        }
                                    }            
                                    else{echo "<tr><td>No elements in cart</td></tr>";}




                                ?>
                               
                            </tbody>
                        </table>
                    </div>
                </form>
                <br>
                <div class="row">
                    <div class="col-sm-4 col-sm-offset-8">
                        <table class="table table-bordered">
                            <tbody><tr>
                            <strong style="font-size: 30px;float: right">Pricing Details</strong>
                            <td class="text-right"><strong>Sub-Total:</strong></td>
                            <td class="text-right"><?php echo"$gtotal" ?></td>
                            </tr>
                            <tr>
                                <td class="text-right">Shipping Charges:</td>
                                <td class="text-right">50</td>
                            </tr>
                            <tr>
                                <td class="text-right"><strong>Order Total:</strong></td>
                                <td class="text-right"><?php if($gtotal!=0){$y=$gtotal+50;echo"$y";} else{echo "0";} ?></td>
                            </tr>
                            </tbody></table>
                    </div>
                </div>
                <div class="buttons">
                    <div class="pull-left"><a class="btn btn-default" href="home.php"><i class="fa fa-caret-right"></i>&nbsp;Continue Shopping</a></div>
                    <div class="pull-right"><a class="btn btn-primary reg_button" href="checkout.php?UID=<?php echo $id; ?>">Checkout</a></div>
                </div>
            </div>
        </div>


        <div id="footer1">
            <div class="container-fluid footer-background">
                <div class="row">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-2 col-sm-3 col-xs-12 txt-center">
                                <a href="home.php">
                                    <span class="logo-text">5 Medi</span>
                                </a>
                            </div>
                            <div class="col-md-7 col-sm-6 col-xs-12">
                                <div id="footer_menu">
                                    <a href="home.php">Home</a> | 
                                    <a href="about_us.html">About Us</a> | 
                                    <a href="contact_us.html">Contact Us</a> 
                                
                                </div>
                            </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                 </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        
        <a style="display: none" href="javascript:void(0);" class="scrollTop back-to-top" id="back-to-top">
            <i class="fa fa-chevron-up"></i>
        </a>
    </body>
</html> 
