<?php
session_start();

include 'db.php';

$result = $mysqli->query("SELECT productName, productPrice, productId, Image FROM productTable;");

$count = $result->num_rows;
function addDiv(){
global $result;
global $count;
while($count >= 0) {
        $row = $result->fetch_row();
        $c4 = $row[3];
        $c0 = $row[2];
        $c1 = $row[0];
        $c2 = $row[1];
                echo '<div class="product-layout  col-md-4 col-sm-6 col-xs-12">
                <div class="product-thumb-height">
                    <div class="product-thumb transition">
                        <ul>
                            <li class="li_product_title">
                                <div class="product_title">
                                    <a href="single-product.php?pid='.$c0.'">'. $c1 .'</a>
                                </div></li>
                            <li class="li_product_image">
                                <div class="image">
                                    <a href="single-product.php?pid='.$c0.'">
                                        <img src="'.$c4.'"  width="200" height="100" />		
                                    </a>
            
                                </div>
                            </li>
                            <li class="li_product_price">
                                <span class="saving1">₹'. $c2 .'</span>
                            <li class="li_product_desc">
                            </li>
                            <li class="li_product_buy_button">
                                <a class="btn btn-default" id="but" href="single-product.php?pid='.$c0.'" role="button" >
                                    Buy Now!
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>';
        $count = $count - 1;
    }
}

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1"/>
        <link rel="icon" href="images/favicon.png"/>
        <title>5MEDI_Home</title>
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
        <link rel="stylesheet" type="text/css" href="css/style.css"/> 
        <link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css"/>
        <link rel="stylesheet" href="css/owl-carousel.css"/>
        <script src="js/jquery.min.js"></script>
        <script src="js/owl-carousel.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/custom.js"></script>
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-sm-4 col-xs-4" id="logo" >
                    <a href="home.php" class="logo-text">
                        5<span style="color:#39BAF0; font-size:40px">MEDI</span>
                    </a>		
                </div>
                <div class="col-md-2 col-sm-12 col-xs-12" style="display:none " id="navbar_hide" >
                    <nav  role="navigation" class="navbar navbar-inverse">
                        <a href="home.php" style="float: left" class="logo-text">
                            5<span style="color:#39BAF0; font-size:40px">MEDI</span>
                        </a>
                        <div id="nav">
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar" style="background: #8EBE08; border: none; margin-right: 0">
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                            </div>
                            <div class="collapse navbar-collapse" id="myNavbar">
                                <ul class="nav navbar-nav site_nav_menu1"  >
                                    <li class="first " ><a href="home.php">Home</a></li>
                                    <li><a href="prescription.php">Upload Prescription</a></li>
                                    <li><a href="cart.php">Shipping & Payment</a></li>
                                    <li><a href="tracking.php">Tracking</a></li>
                                    <li><a href="about_us.html">About us</a></li>
                                    <li><a href="contact_us.html">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                    </nav>
                </div>
                <div class="col-md-4 col-md-offset-4 col-sm-offset-2 col-sm-6 col-xs-12" >
                    <div id="top_right">
                        <div id="cart">
                            <div class="text">
                                <div class="img">
                                    </div>
                            </div> 
                        </div>
                        <div id="bottom_right">
                            <div class="row">
                                <div class="col-md-6 col-xs-6 wd_auto">
                                    <div class="right">
                                        <div class="login">
                                            <?php
                                                if(isset($_SESSION['UID'])){
                                                    echo '<a class="btn btn-default reg_button" href="#">'.$_SESSION["name"].'</a>
                                                    <a class="btn btn-default reg_button" href="logout.php">logout</a>';
                                                }
                                                else{
                                                    echo '<a class="btn btn-default reg_button" href="login.html">Login</a> 
                                                    <a class="btn btn-default reg_button" href="register.html">Signup</a>';
                                                }
                                            ?>
                                        </div>			
                                    </div>
                                </div> 
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div> 
        <div class="container-fluid bg-color">
            <div class="row">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 col-xs-12">
                            <nav  role="navigation" class="navbar navbar-inverse" id="nav_show">
                                <div id="nav">
                                    <div class="navbar-header">
                                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                                            <span class="icon-bar"></span>
                                            <span class="icon-bar"></span>
                                            <span class="icon-bar"></span>
                                        </button>

                                    </div>
                                    <div class="collapse navbar-collapse" id="myNavbar">
                                        <ul class="nav navbar-nav site_nav_menu1"  >
                                            <li class="first "><a href="home.php">Home</a></li>
                                            <li><a href="prescription.php">Upload Prescription</a></li>
                                            <li><a href="cart.php?UID = <?php echo $_SESSION['UID']?>">Shipping & Payment</a></li>
                                            <li><a href="tracking.php">Tracking</a></li>
                                            <li><a href="about_us.html">About us</a></li>
                                            <li><a href="contact_us.html">Contact Us</a></li>
                                        </ul>

                                    </div>
                                </div>
                            </nav>
                        </div>
                    </div> 

                </div>
            </div>
        </div>

        <div id="site_content">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-4 col-xs-12 left_sidebar1">
                        <div id="left_part">
                            <div class="bs-example">
                                <div class="panel-group" id="accordion">
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <div class="infoBoxHeading">
                                                <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">Category Of Agent</a>
                                                <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
                                                    <i  id="accordan_plus" class="indicator glyphicon glyphicon-chevron-down  pull-right"></i>
                                                </a>
                                            </div>
                                        </div>
                                        <div id="collapseOne" class="panel-collapse collapse in">
                                            <div class="panel-body">
                                                <div class="infoBoxContents">
                                                    <a href="medical-services.php#doc">24 Hr Doctor</a><br />
                                                    <a href="medical-services.php#sam">Collection of samples / lab</a><br />
                                                    <a href="medical-services.php#bp">B.P. Recording</a><br />
                                                    <a href="medical-services.php#iw">Injection / Wound Care</a><br />
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>
                        <script>
                            function toggleChevron(e) {
                                $(e.target)
                                        .prev('.panel-heading')
                                        .find("i.indicator")
                                        .toggleClass('glyphicon-chevron-down glyphicon-chevron-up');
                            }
                            $('#accordion').on('hidden.bs.collapse', toggleChevron);
                            $('#accordion').on('shown.bs.collapse', toggleChevron);
                        </script>

                    </div> 
                    <div class="col-md-9 col-sm-8 col-xs-12 right_sidebar1">
                        <div id="right_part">
                                <div class="contentText">
                                    <h1>Products</h1>
                                    <div class="row margin-top product-layout_width" id="unique">
                                            <?php addDiv(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>

        <div id="footer1"">
            <div class="container-fluid footer-background">
                <div class="row">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-2 col-sm-3 col-xs-12 txt-center">
                                <a href="home.php">
                                    <span class="logo-text">5MEDI</span>
                                </a>
                            </div>
                            <div class="col-md-7 col-sm-6 col-xs-12">
                                <div id="footer_menu">
                                    <a href="home.php">Home</a> | 
                                    <a href="about_us.html">About Us</a> |
                                    <a href="cart.php">Shipping & Payment</a> |
                                    <a href="contact_us.html">Contact Us</a> |
                                    <a href="tracking.php">Tracking</a><span></span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <a style="display: none" href="javascript:void(0);" class="scrollTop back-to-top" id="back-to-top">
            <i class="fa fa-chevron-up"></i>
        </a>
    </body>
</html> 
