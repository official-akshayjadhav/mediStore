<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1"/>
        <link rel="icon" href="images/favicon.png"/>
        <title>5Medi</title>
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
        <link rel="stylesheet" type="text/css" href="css/style.css"/>
        <link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css"/>
        <link rel="stylesheet" href="css/owl-carousel.css"/>
        <script src="js/jquery.min.js"></script>
        <script src="js/owl-carousel.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/custom.js"></script>
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-sm-4 col-xs-4" id="logo" >
                    <a href="home.php" class="logo-text">
                        5<span style="color:#39BAF0; font-size:40px">Medi</span>
                    </a>
                </div>
                <div class="col-md-2 col-sm-12 col-xs-12" style="display:none " id="navbar_hide" >
                    <nav  role="navigation" class="navbar navbar-inverse">
                        <a href="home.php" style="float: left" class="logo-text">
                            5<span style="color:#39BAF0; font-size:40px">Medi</span>
                        </a>
                        <div id="nav">
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar" style="background: #8EBE08; border: none; margin-right: 0">
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                            </div>
                            <div class="collapse navbar-collapse" id="myNavbar">
                                <ul class="nav navbar-nav site_nav_menu1"  >
                                    <li class="first " ><a href="home.php">Home</a></li>
                                    <li><a href="cart.php">Shipping & Payment</a></li>
                                    <li><a href="tracking.php">Tracking</a></li>
                                    <li><a href="about_us.html">About Us</a></li>
                                    <li><a href="contact_us.html">Contact</a></li>
                                </ul>
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
        <div class="container-fluid bg-color">
            <div class="row">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 col-xs-12">
                            <nav  role="navigation" class="navbar navbar-inverse" id="nav_show">
                                <div id="nav">
                                    <div class="navbar-header">
                                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                                            <span class="icon-bar"></span>
                                            <span class="icon-bar"></span>
                                            <span class="icon-bar"></span>
                                        </button>

                                    </div>
                                    <div class="collapse navbar-collapse" id="myNavbar">
                                        <ul class="nav navbar-nav site_nav_menu1"  >
                                        <li class="first " ><a href="home.php">Home</a></li>
                                        <li><a href="cart.php">Shipping & Payment</a></li>
                                        <li><a href="tracking.php">Tracking</a></li>
                                        <li><a href="about_us.html">About Us</a></li>
                                        <li><a href="contact_us.html">Contact</a></li>
                                        </ul>

                                    </div>
                                </div>
                            </nav>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <div style="text-align:center">
            <h1>
                Your order is placed sucessfully !!!
            </h1>
            <br>
            <h2>
                We will contact you soon.
            </h2>
            <br>
            <?php
            echo "<h3>Visiting charges are Rs" . $_GET["value"] . ",Please Pay On Delivery</h3>";
            ?>
            </div>
        
        
        
        
        <div id="footer1" style="position:fixed;bottom:0;width:100%">
            <div class="container-fluid footer-background">
                <div class="row">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-2 col-sm-3 col-xs-12 txt-center">
                                <a href="home.php">
                                    <span class="logo-text">5MEDI</span>
                                </a>
                            </div>
                            <div class="col-md-7 col-sm-6 col-xs-12">
                                <div id="footer_menu">
                                    <a href="home.php">Home</a> |
                                    <a href="cart.php">Shipping & Payment</a> |
                                    <a href="medical-services.html">Medical Services</a> |
                                    <a href="tracking.php">Tracking</a>|
                                    <a href="about_us.html">About Us</a> |
                                    <a href="contact_us.html">Contact</a> <span></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <a style="display: none" href="javascript:void(0);" class="scrollTop back-to-top" id="back-to-top">
            <i class="fa fa-chevron-up"></i>
        </a>
    </body>
</html>
