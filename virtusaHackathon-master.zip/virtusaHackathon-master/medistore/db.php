<?php
/* Database connection settings */
$host = 'localhost';
$user = 'splitloo_5techg';
$pass = 'imnotfake2017';
$db = 'mediDatabase';
$mysqli = new mysqli($host,$user,$pass,$db) or die($mysqli->error);
?>