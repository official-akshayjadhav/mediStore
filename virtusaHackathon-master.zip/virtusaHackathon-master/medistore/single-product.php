<?php
/* User login process, checks if user exists and password is correct */
session_start();
include 'db.php';

if(isset($_GET['pid'])){
    $_SESSION['pid'] = $_GET['pid']; 
}
if(isset($_SESSION['UID']) && !empty($_SESSION['UID'])) {
    $uid = $_SESSION['UID'];
}
else{
    header('location: home.php');
}

$productIdVar = $_SESSION['pid'];

if(isset($_POST['quantity'])){
    $q = $_POST['quantity'];
    
    //updated code **
    
    //get the UID and PID from the table 
    $res = $mysqli->query("select UID,PID,count from cart where UID=".$uid."and pid=".$productIdVar.";");
    if($res->num_rows == 0){
        
        //logic to insert to the table 
        $result = $mysqli->query("INSERT INTO cart(UID, PID, count) VALUES($uid,$productIdVar , $q);");
    }else{
        //update the specific row
        $rowOfCart = $res->fetch_row();    
        $updatedCount = rowOfCart[2] + $q;
        //update the table
        $mysqli->query("update cart set count=".$updatedCount."where UID=".$uid."and pid=".$productIdVar.";");
    }
    
    // updated code ^
    
    
    if (!$result) {
        echo 'Could not run query: ' . mysql_error();
        exit;
    }
}

$result = $mysqli->query(" SELECT productName,productPrice,productDescription,Image FROM productTable where productId = ".$_SESSION['pid'].";");

if (!$result) {
    echo 'Could not run query: ' . mysql_error();
    exit;
}

/* get the row data from result*/
$row = $result->fetch_row();

/* store the data in php var */
$productName = $row[0];
$productPrice = $row[1];
$productDescription = $row[2];
$productImage = $row[3];
?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1"/>
        <link rel="icon" href="images/favicon.png"/>
        <title>DRUGs</title>
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
        <link rel="stylesheet" type="text/css" href="css/style.css"/> 
        <link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css"/>
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/custom.js"></script>
    </head>
    <body>
            <div class="container">
                <div class="row">
                    <div class="col-md-4 col-sm-4 col-xs-4" id="logo" >
                        <a href="home.php" class="logo-text">
                            DRUG<span style="color:#39BAF0; font-size:40px">s</span>
                        </a>		
                    </div>
                    <div class="col-md-2 col-sm-12 col-xs-12" style="display:none " id="navbar_hide" >
                        <nav  role="navigation" class="navbar navbar-inverse">
                            <a href="home.php" style="float: left" class="logo-text">
                                Medi<span style="color:#39BAF0; font-size:40px">STORE</span>
                            </a>
                            <div id="nav">
                                <div class="navbar-header">
                                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar" style="background: #8EBE08; border: none; margin-right: 0">
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                    </button>
                                </div>
                                <div class="collapse navbar-collapse" id="myNavbar">
                                    <ul class="nav navbar-nav site_nav_menu1"  >
                                        <li class="first " ><a href="home.php">Home</a></li>
                                        <li><a href="about_us.html">About us</a></li>
                                        <li><a href="cart.php">Shipping & Payment</a></li>
                                        <li><a href="#">Privacy Policy</a></li>
                                        <li><a href="#">Terms & Conditions</a></li>
                                        <li><a href="#">Contact Us</a></li>
                                    </ul>
                                </div>
                            </div>
                        </nav>
                    </div>
                    <div class="col-md-4 col-md-offset-4 col-sm-offset-2 col-sm-6 col-xs-12" >
                        <div id="top_right">
                            <div id="cart">
                                <div class="text">
                                    <div class="img">
                                        <a href="cart.html"> <img class="img-responsive" src="images/cart.png" alt="" title="" width="26" height="27" /></a>
                                    </div><span>Your cart:</span><span class="cart_total">₹0.00</span><span class="cart_items">(0 items)</span>
                                </div> 
                            </div>
                            <div id="bottom_right">
                                <div class="row">
                                    <div class="col-md-6 col-xs-6 wd_auto">
                                        <div class="right">
                                            <div class="login">
                                                <a class="btn btn-default reg_button" href="login.html">Login</a> 
                                                <a class="btn btn-default reg_button" href="register.html">Signup</a>
                                            </div>			
                                        </div>
                                    </div> 
                                </div>
                            </div>
                        </div>
    
                    </div>
                </div>
            </div> 
            <div class="container-fluid bg-color">
                <div class="row">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12 col-xs-12">
                                <nav  role="navigation" class="navbar navbar-inverse" id="nav_show">
                                    <div id="nav">
                                        <div class="navbar-header">
                                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                                                <span class="icon-bar"></span>
                                                <span class="icon-bar"></span>
                                                <span class="icon-bar"></span>
                                            </button>
    
                                        </div>
                                        <div class="collapse navbar-collapse" id="myNavbar">
                                            <ul class="nav navbar-nav site_nav_menu1"  >
                                                <li class="first "><a href="home.php">Home</a></li>
                                                <li><a href="about_us.html">About us</a></li>
                                                <li><a href="cart.php">Shipping & Payment</a></li>
                                                <li><a href="#">Privacy Policy</a></li>
                                                <li><a href="#">Terms & Conditions</a></li>
                                                <li><a href="#">Contact Us</a></li>
                                            </ul>
    
                                        </div>
                                    </div>
                                </nav>
                            </div>
                        </div> 
    
                    </div>
                </div>
            </div>
            <div class="container" >
                <!--<div class="row" id="search_manu" style="margin-top: 10px">-->
                <!--    <div class="col-md-6 col-xs-12">-->
                <!--        <form  name="quick_find">-->
                <!--            <div class="form-group">-->
                <!--                <div class="input-group">-->
                <!--                    <input type="text" placeholder="Enter search keywords here" class="form-control input-lg" id="inputGroup"/>-->
                <!--                    <span class="input-group-addon">-->
                <!--                        <a href="#" style="color:white">Search</a>-->
                <!--                    </span>-->
                <!--                </div>-->
                <!--            </div>-->
                <!--        </form>-->
                <!--    </div>-->
                    <!--<div class="col-md-6 col-xs-12">-->
                    <!--        <form  name="manufacturers">-->
                    <!--            <div class="form-group">-->
                    <!--                <div class="">-->
                    <!--                    <select  style="font-size: 14px; background: #EAEAEA; border: none;" name="manufacturers_id"  size="1" class="input-lg form-control arrow-hide date_class">-->
                    <!--                        <option value="" selected="selected">Category of Agent</option>-->
                    <!--                        <option>24 Hr Doctor</option>-->
                    <!--                        <option>Collection of samples and lab investigation</option>-->
                    <!--                        <option>B.P. Recording</option>-->
                    <!--                        <option>Injection / Wound Care</option>-->
                    <!--                    </select>-->
        
                    <!--                </div>-->
                    <!--            </div>-->
                    <!--        </form>-->
                    <!--    </div>-->
                    </div>
                </div>
    

        <div id="site_content">
            <div class="container">
                <div class="row">
        <!--            <div class="col-md-3 col-sm-4 col-xs-12 left_sidebar1">-->
                        <!--<div id="left_part">-->
                        <!--    <div class="bs-example">-->
                                <!--<div class="panel-group" id="accordion">-->
                                <!--    <div class="panel panel-default">-->
                                <!--        <div class="panel-heading">-->
                                <!--            <div class="infoBoxHeading">-->
                                <!--                <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">Categories</a>-->
                                <!--                <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">-->
                                <!--                    <i  id="accordan_plus" class="indicator glyphicon glyphicon-chevron-down  pull-right"></i>-->
                                <!--                </a>-->
                                <!--            </div>-->
                                <!--        </div>-->
                                <!--        <div id="collapseOne" class="panel-collapse collapse in">-->
                                <!--            <div class="panel-body">-->
                                <!--                <div class="infoBoxContents">-->
                                <!--                    <a href="product.html">Category One</a>&nbsp;(94)<br />-->
                                <!--                    <a href="product.html">Category Two</a>&nbsp;(9)<br />-->
                                <!--                </div>-->
                                <!--            </div>-->
                                <!--        </div>-->
                                <!--    </div>-->

                                <!--</div>-->

                        <!--    </div>-->
                        <!--</div>-->
                        <!--<script>-->
                        <!--    function toggleChevron(e) {-->
                        <!--        $(e.target)-->
                        <!--                .prev('.panel-heading')-->
                        <!--                .find("i.indicator")-->
                        <!--                .toggleClass('glyphicon-chevron-down glyphicon-chevron-up');-->
                        <!--    }-->
                        <!--    $('#accordion').on('hidden.bs.collapse', toggleChevron);-->
                        <!--    $('#accordion').on('shown.bs.collapse', toggleChevron);-->
                        <!--</script>-->

                    </div> 
                    <div class="col-md-9 col-sm-8 col-xs-12" id="content">            
                        <div class="breadcrumbs">
                            <a href="home.php"><i class="fa fa-home"></i></a>
                            <a href="">Lorem</a>
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <ul class="thumbnails">
                                    <li><a  href="#" class="thumbnail fix-box"><img class="changeimg" src="<?php echo $productImage; ?>"></a></li>
                                </ul>
                            </div>
                            <div class="col-sm-6">
                                <ul class="list-unstyled product-section">
                                    <li><span>Product Code:</span> <?php echo $productIdVar ?></li>
                                </ul>
                                <ul class="list-unstyled">
                                    <li>
                                        <h1><?php echo $productName?></h1>
                                    </li>
                                    <li>
                                        <h2>₹<?php echo $productPrice ?></h2>
                                    </li>
                                    <li><p><?php echo $productDescription ?></p></li>
                                </ul>
                                <div id="product">
                                    <div class="form-group">
                                        <form  action="single-product.php" method="post">
                                            <label for="input-quantity" class="control-label">Quantity</label>
                                            <input type="number" class="form-control" id="input-quantity" size="2" value="1" min=0 oninput="validity.valid||(value='');" name="quantity">
                                            <input type="hidden" value="49" name="product_id">
                                            <br>
                                        
                                             <button id = "add-to-cart-btn" type="submit" class="btn btn-primary btn-lg btn-block reg_button"><i class="fa fa-shopping-cart"></i> Add to Cart</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                        </div>
                    </div>

                </div>
            </div>
        </div>

        
        <!--<div id="footer1"" style="position: fixed; bottom: 0; width: 100%;">-->
        <!--        <div class="container-fluid footer-background">-->
        <!--            <div class="row">-->
        <!--                <div class="container">-->
        <!--                    <div class="row">-->
        <!--                        <div class="col-md-2 col-sm-3 col-xs-12 txt-center">-->
        <!--                            <a href="home.php">-->
        <!--                                <span class="logo-text">DRUGSTORE</span>-->
        <!--                            </a>-->
        <!--                        </div>-->
        <!--                        <div class="col-md-7 col-sm-6 col-xs-12">-->
        <!--                            <div id="footer_menu">-->
        <!--                                <a href="home.php">Home</a> | -->
        <!--                                <a href="#">About Us</a> |-->
        <!--                                <a href="#">Shipping & Payment</a> | -->
        <!--                                <a href="#">Privacy Policy</a> <br class="disable_content" />-->
        <!--                                <a href="#">Terms & Conditions</a> | -->
        <!--                                <a href="#">Contact Us</a> | <span></span>-->
        <!--                            </div>-->
        <!--                        </div>-->
        <!--                    </div>-->
        <!--                </div>-->
        <!--            </div>-->
        <!--        </div>-->
        <!--    </div>-->
          
            <a style="display: none" href="javascript:void(0);" class="scrollTop back-to-top" id="back-to-top">
                <i class="fa fa-chevron-up"></i>
        </a>
        <!-- <script>
            $("document").ready(function () {

                $(".galleryimg").on("click", function () {
                    var src = $(this).attr('src');
                    console.log(src)
                    $(".changeimg").attr('src', src);
                });
            });
        </script> -->
    </body>
</html> 