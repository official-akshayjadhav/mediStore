<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1"/>
        <link rel="icon" href="images/favicon.png"/>
        <title>5Medi</title>
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
        <link rel="stylesheet" type="text/css" href="css/style.css"/>
        <link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css"/>
        <link rel="stylesheet" href="css/owl-carousel.css"/>
        <script src="js/jquery.min.js"></script>
        <script src="js/owl-carousel.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/custom.js"></script>
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-sm-4 col-xs-4" id="logo" >
                    <a href="home.php" class="logo-text">
                        5<span style="color:#39BAF0; font-size:40px">Medi</span>
                    </a>
                </div>
                <div class="col-md-2 col-sm-12 col-xs-12" style="display:none " id="navbar_hide" >
                    <nav  role="navigation" class="navbar navbar-inverse">
                        <a href="home.php" style="float: left" class="logo-text">
                            5<span style="color:#39BAF0; font-size:40px">Medi</span>
                        </a>
                        <div id="nav">
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar" style="background: #8EBE08; border: none; margin-right: 0">
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                            </div>
                            <div class="collapse navbar-collapse" id="myNavbar">
                                <ul class="nav navbar-nav site_nav_menu1"  >
                                    <li class="first " ><a href="home.php">Home</a></li>
                                    <li><a href="cart.php">Shipping and Payment</a></li>
                                    <li><a href="medical-services.php">Medical Services</a></li>
                                    <li><a href="tracking.php">Tracking</a></li>
                                    <li><a href="about_us.html">About Us</a></li>
                                    <li><a href="contact_us.html">Contact</a></li>
                                </ul>
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
        <div class="container-fluid bg-color">
            <div class="row">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 col-xs-12">
                            <nav  role="navigation" class="navbar navbar-inverse" id="nav_show">
                                <div id="nav">
                                    <div class="navbar-header">
                                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                                            <span class="icon-bar"></span>
                                            <span class="icon-bar"></span>
                                            <span class="icon-bar"></span>
                                        </button>

                                    </div>
                                    <div class="collapse navbar-collapse" id="myNavbar">
                                        <ul class="nav navbar-nav site_nav_menu1"  >
                                            <li class="first "><a href="home.php">Home</a></li>
                                            <li><a href="cart.php">Shipping and Payment</a></li>
                                            <li><a href="medical-services.html">Medical Services</a></li>
                                            <li><a href="tracking.php">Tracking</a></li>
                                            <li><a href="about_us.html">About Us</a></li>
                                            <li><a href="contact_us.html">Contact</a></li>
                                        </ul>

                                    </div>
                                </div>
                            </nav>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <div class="container" >
            <div class="row" id="search_manu" style="margin-top: 10px">
                                <div class="col-md-6 col-xs-12">
                        <form  name="manufacturers">
                            <div class="form-group">
                                <div class="m">
                                    
                                    <select id="select-anchor" style="font-size: 14px; background: #EAEAEA; border: none;" name="manufacturers_id"  size="1" class="input-lg form-control arrow-hide date_class">
                                        <option>Category of Agent</option>
                                        <option value="#doc">24 Hr Doctor</option>
                                        <option value="#sam">Collection of samples and lab investigation</option>
                                        <option value="#bp">B.P. Recording</option>
                                        <option value="#iw">Injection / Wound Care</option>
                                    </select>
                                    <script>
                                        $(document).ready(function () {
                                        $('#select-anchor').change( function () {
                                                var targetPosition = $($(this).val()).offset().top;
                                                $('html,body').animate({ scrollTop: targetPosition}, 'slow');
                                            });
                                        });
                                    </script>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        <div id="site_content">
            <div class="container">
                <div class="row">
                    <div class="col-md-9 col-sm-8 col-xs-12 right_sidebar1">
                        <div id="right_part">
                                <div class="contentText">
                                    <h1>Medical Services</h1><br>
                                    <div id="doc">
                                    <h3>24 hr Doctor</h3>
                                    <div class="row margin-top product-layout_width">
                                        <div class="product-layout  col-md-4 col-sm-6 col-xs-12">
                                            <div class="product-thumb-height">
                                                <div class="product-thumb transition">
                                                    <ul>
                                                        <li class="li_product_title">
                                                            <div class="product_title">
                                                                Dr. Rohit Agharkar<br>
                                                                (M.D)<br>
                                                                ASR Hospital<br>
                                                                Contact no.: 7584869585<br>
                                                                Visiting charges:Rs 200<br>
                                                            </div></li>
                                                            <a class="btn btn-default"  href="check.php?value=200" role="button" >
                                                            TAKE APPOINMENT
                                                        </a>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="product-layout  col-md-4 col-sm-6 col-xs-12">
                                            <div class="product-thumb-height">
                                                <div class="product-thumb transition">
                                                  <ul>
                                                      <li class="li_product_title">
                                                          <div class="product_title">
                                                              Dr. Utkarsh Mishra<br>
                                                              (M.B.B.S)<br>
                                                              MSU Hospital<br>
                                                              Contact no.: 1425587495<br>
                                                              Visiting charges:Rs 250<br>
                                                          </div></li>
                                                          <a class="btn btn-default"  href="check.php?value=250" role="button" >
                                                          TAKE APPOINMENT
                                                      </a>
                                                  </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="product-layout  col-md-4 col-sm-6 col-xs-12">
                                            <div class="product-thumb-height">
                                                <div class="product-thumb transition">
                                                  <ul>
                                                      <li class="li_product_title">
                                                          <div class="product_title">
                                                              Dr. Niyati Bavishi<br>
                                                              (M.D)<br>
                                                              BRN Hospital<br>
                                                              Contact no.: 4857956823<br>
                                                              Visiting charges:Rs 200<br>
                                                          </div></li>
                                                          <a class="btn btn-default"  href="check.php?value=200" role="button" >
                                                          TAKE APPOINMENT
                                                      </a>
                                                  </ul>
                                                </div>
                                            </div>
                                        </div>
                                        </div>
                                        <div id="sam">
                                        <br>
                                        <h3>Collection of samples and lab investigation</h3><br>
                                        <div class="product-layout  col-md-4 col-sm-6 col-xs-12">
                                            <div class="product-thumb-height">
                                                <div class="product-thumb transition">
                                                    <ul>
                                                        <li class="li_product_title">
                                                            <div class="product_title">
                                                                ABC Pathology Lab<br>
                                                                Pune<br>
                                                                Contact no.:1548564958<br>
                                                                Timings:MON - SAT<br>
                                                                (8:00 am to 1:30 pm)<br>
                                                                (4:00 pm to 9:00 pm)<br>
                                                                Sunday Closed<br>
                                                                Charges:Rs 250<br>
                                                            </div></li>
                                                            <a class="btn btn-default"  href="check.php?value=250" role="button" >
                                                            TAKE APPOINMENT
                                                        </a>
                                                      </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="product-layout  col-md-4 col-sm-6 col-xs-12">
                                            <div class="product-thumb-height">
                                                <div class="product-thumb transition">
                                                  <ul>
                                                      <li class="li_product_title">
                                                          <div class="product_title">
                                                              DEF Pathology Lab<br>
                                                              Pune<br>
                                                              Contact no.:5286859758<br>
                                                              Timings:MON - SAT<br>
                                                              (9:00 am to 1:30 pm)<br>
                                                              (4:00 pm to 9:30 pm)<br>
                                                              Sunday Closed<br>
                                                              Charges:Rs 250<br>
                                                          </div></li>
                                                          <a class="btn btn-default"  href="check.php?value=250" role="button" >
                                                          TAKE APPOINMENT
                                                      </a>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="product-layout  col-md-4 col-sm-6 col-xs-12">
                                            <div class="product-thumb-height">
                                                <div class="product-thumb transition">
                                                    <ul>
                                                        <li class="li_product_title">
                                                            <div class="product_title">
                                                                GHI Pathology Lab<br>
                                                                Pune<br>
                                                                Contact no.:8596853265<br>
                                                                Timings:MON - SAT<br>
                                                                (8:00 am to 1:30 pm)<br>
                                                                (4:00 pm to 9:00 pm)<br>
                                                                Sunday Closed<br>
                                                                Charges:Rs 250<br>
                                                            </div></li>
                                                            <a class="btn btn-default"  href="check.php?value=250" role="button" >
                                                            TAKE APPOINMENT
                                                        </a>
                                                        </ul>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div id="bp">
                                        <br>
                                        <h3>B.P. Recording</h3><br>
                                        <div class="product-layout  col-md-4 col-sm-6 col-xs-12">
                                            <div class="product-thumb-height">
                                                <div class="product-thumb transition">
                                                  <ul>
                                                      <li class="li_product_title">
                                                          <div class="product_title">
                                                              LMN Hospital<br>
                                                              Contact no.:7485968596<br>
                                                              Timings:MON - SAT<br>
                                                              (8:00 am to 12:00 pm)<br>
                                                              (5:00 pm to 8:00 pm)<br>
                                                              Sunday Closed<br>
                                                              Charges:Rs 100<br>
                                                          </div></li>
                                                          <a class="btn btn-default"  href="check.php?value=100" role="button" >
                                                          TAKE APPOINMENT
                                                      </a>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="product-layout  col-md-4 col-sm-6 col-xs-12">
                                            <div class="product-thumb-height">
                                                <div class="product-thumb transition">
                                                  <ul>
                                                      <li class="li_product_title">
                                                          <div class="product_title">
                                                              XYZ Hospital<br>
                                                              Contact no.:4968597592<br>
                                                              Timings:MON - FRI<br>
                                                              (8:00 am to 12:00 pm)<br>
                                                              (5:00 pm to 8:00 pm)<br>
                                                              Saturday,Sunday Closed<br>
                                                              Charges:Rs 100<br>
                                                          </div></li>
                                                          <a class="btn btn-default"  href="check.php?value=100" role="button" >
                                                          TAKE APPOINMENT
                                                      </a>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="product-layout  col-md-4 col-sm-6 col-xs-12">
                                            <div class="product-thumb-height">
                                                <div class="product-thumb transition">
                                                  <ul>
                                                      <li class="li_product_title">
                                                          <div class="product_title">
                                                              PQR Hospital<br>
                                                              Contact no.:1458659586<br>
                                                              Timings:MON,WED,FRI<br>
                                                              (8:00 am to 12:00 pm)<br>
                                                              (5:00 pm to 8:00 pm)<br>
                                                              Charges:Rs 100<br>
                                                          </div></li>
                                                          <a class="btn btn-default"  href="check.php?value=100" role="button" >
                                                          TAKE APPOINMENT
                                                      </a>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        </div>
                                        <div id="iw">
                                        <br>
                                        <h3>Injection / Wound Care</h3><br>
                                        <div class="product-layout  col-md-4 col-sm-6 col-xs-12">
                                            <div class="product-thumb-height">
                                                <div class="product-thumb transition">
                                                    <ul>
                                                        <li class="li_product_title">
                                                            <div class="product_title">
                                                                Dr. Aditya Kulkarni<br>
                                                                (M.D)<br>
                                                                KBA Hospital<br>
                                                                Contact no.: 2541526358<br>
                                                                Visiting charges:Rs 250<br>
                                                            </div>
                                                            <a class="btn btn-default"  href="check.php?value=250" role="button" >
                                                            TAKE APPOINMENT
                                                        </a>
                                                      </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="product-layout  col-md-4 col-sm-6 col-xs-12">
                                            <div class="product-thumb-height">
                                                <div class="product-thumb transition">
                                                  <ul>
                                                      <li class="li_product_title">
                                                          <div class="product_title">
                                                              Dr. Akshay Jadhav<br>
                                                              (M.B.B.S)<br>
                                                              JMA Hospital<br>
                                                              Contact no.: 1458968568<br>
                                                              Visiting charges:Rs 250<br>
                                                          </div>
                                                          <a class="btn btn-default"  href="check.php?value=250" role="button" >
                                                          TAKE APPOINMENT
                                                      </a>
                                                    </li>
                                                  </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    </div>
                                </div>
                                
                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>

        <div id="footer1">
            <div class="container-fluid footer-background">
                <div class="row">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-2 col-sm-3 col-xs-12 txt-center">
                                <a href="home.php">
                                    <span class="logo-text">DRUGSTORE</span>
                                </a>
                            </div>
                            <div class="col-md-7 col-sm-6 col-xs-12">
                                <div id="footer_menu">
                                    <a href="home.php">Home</a> |
                                    <a href="#">About Us</a> |
                                    <a href="#">Shipping & Payment</a> |
                                    <a href="#">Medical Services</a> |
                                    <a href="tracking.php">Tracking</a>|
                                    <a href="#">Contact Us</a> | <span></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <a style="display: none" href="javascript:void(0);" class="scrollTop back-to-top" id="back-to-top">
            <i class="fa fa-chevron-up"></i>
        </a>
    </body>
</html>
