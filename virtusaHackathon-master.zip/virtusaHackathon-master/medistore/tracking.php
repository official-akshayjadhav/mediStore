<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1"/>
        <link rel="icon" href="images/favicon.png"/>
        <title>5MEDI_Tracking</title>
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
        <link rel="stylesheet" type="text/css" href="css/style.css"/> 
        <link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css"/>
        <link rel="stylesheet" href="css/owl-carousel.css"/>
        <script src="js/jquery.min.js"></script>
        <script src="js/owl-carousel.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/custom.js"></script>
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-sm-4 col-xs-4" id="logo" >
                    <a href="home.php" class="logo-text">
                        5<span style="color:#39BAF0; font-size:40px">MEDI</span>
                    </a>		
                </div>
                <div class="col-md-2 col-sm-12 col-xs-12" style="display:none " id="navbar_hide" >
                    <nav  role="navigation" class="navbar navbar-inverse">
                        <a href="home.php" style="float: left" class="logo-text">
                            5<span style="color:#39BAF0; font-size:40px">MEDI</span>
                        </a>
                        <div id="nav">
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar" style="background: #8EBE08; border: none; margin-right: 0">
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                            </div>
                            <div class="collapse navbar-collapse" id="myNavbar">
                                <ul class="nav navbar-nav site_nav_menu1"  >
                                    <li class="first " ><a href="home.php">Home</a></li>
                                    <li><a href="prescription.php">Upload Prescription</a></li>
                                    <li><a href="cart.php">Shipping & Payment</a></li>
                                    <li><a href="tracking.php">Tracking</a></li>
                                    <li><a href="about_us.html">About us</a></li>
                                    <li><a href="contact_us.html">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                    </nav>
                </div>
                <div class="col-md-4 col-md-offset-4 col-sm-offset-2 col-sm-6 col-xs-12" >
                    <div id="top_right">
                        <div id="cart">
                            <div class="text">
                                <div class="img">
                                    </div>
                            </div> 
                        </div>
                        <div id="bottom_right">
                            <div class="row">
                                <div class="col-md-6 col-xs-6 wd_auto">
                                    <div class="right">
                                        <div class="login">
                                            <?php
                                                if(isset($_SESSION['UID'])){
                                                    echo '<a class="btn btn-default reg_button" href="#">'.$_SESSION["name"].'</a>
                                                    <a class="btn btn-default reg_button" href="logout.php">logout</a>';
                                                }
                                                else{
                                                    echo '<a class="btn btn-default reg_button" href="login.html">Login</a> 
                                                    <a class="btn btn-default reg_button" href="register.html">Signup</a>';
                                                }
                                            ?>
                                        </div>			
                                    </div>
                                </div> 
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div> 
        <div class="container-fluid bg-color">
            <div class="row">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 col-xs-12">
                            <nav  role="navigation" class="navbar navbar-inverse" id="nav_show">
                                <div id="nav">
                                    <div class="navbar-header">
                                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                                            <span class="icon-bar"></span>
                                            <span class="icon-bar"></span>
                                            <span class="icon-bar"></span>
                                        </button>

                                    </div>
                                    <div class="collapse navbar-collapse" id="myNavbar">
                                        <ul class="nav navbar-nav site_nav_menu1"  >
                                            <li class="first "><a href="home.php">Home</a></li>
                                            <li><a href="prescription.php">Upload Prescription</a></li>
                                            <li><a href="cart.php?UID = <?php echo $_SESSION['UID']?>">Shipping & Payment</a></li>
                                            <li><a href="tracking.php">Tracking</a></li>
                                            <li><a href="about_us.html">About us</a></li>
                                            <li><a href="contact_us.html">Contact Us</a></li>
                                        </ul>

                                    </div>
                                </div>
                            </nav>
                        </div>
                    </div> 

                </div>
            </div>
        </div>
          <!----->
          
          
          
          <div class="container">
    <div class="row">
        <div class="board">
            <ul class="nav nav-tabs">
                <div class="liner"></div>
                <li rel-index="0" class="active" id="step-1-next">
                    <a href="#step-1" class="btn" aria-controls="step-1" role="tab" data-toggle="tab" title="Order Processing">
                        <span><i class="glyphicon glyphicon-save"></i></span>
                    </a>
                    <font size="6">PLACED</font>
                </li>
                <li rel-index="1" id="step-2-next">
                    <a href="#step-2" class="btn disabled" aria-controls="step-2" role="tab" data-toggle="tab" title="Pre-Production">
                        <span><i class="glyphicon glyphicon-time"></i></span>
                    </a>
                    <font size="6">PROCESSING</font>
                </li>
                <li rel-index="2" id="step-3-next">
                    <a href="#step-3" class="btn disabled" aria-controls="step-3" role="tab" data-toggle="tab" title="Shipped">
                        <span><i class="glyphicon glyphicon-gift"></i></span>
                    </a>
                    <font size="6">SHIPPED</font>
                </li>
                <li rel-index="3" id="step-4-next">
                    <a href="#step-4" class="btn disabled" aria-controls="step-4" role="tab" data-toggle="tab" title="Delivered">
                        <span><i class="glyphicon glyphicon-thumbs-up"></i></span>
                    </a>
                    <font size="6">DELIVERED</font>
                </li>
            </ul>
        </div>
      <div class="tab-content">
      <div role="tabpanel" class="tab-pane active" id="step-1">
      
        </div>
        </div>
      
    </div>
</div>
<style>
/* Main tabs */
@import url(http://fonts.googleapis.com/css?family=Roboto+Condensed:400,700);

body {
    font-family: 'Roboto Condensed', san-serif;
    background: white;
}

.board {
    width: 100%;
    height: auto;
    margin: 30px auto;
    background: none;
}

.board .nav-tabs {
    position: relative;
    margin: 40px auto;
    margin-bottom: 0;
    box-sizing: border-box;
}

.liner {
    height: 2px;
    background: white;
    position: absolute;
    width: 80%;
    margin: 0 auto;
    left: 0;
    right: 0;
    top: 50%;
    z-index: 1;
}

.nav-tabs > li {
    width: 25%;
}

.nav-tabs > li:after {
    content: " ";
    position: absolute;
    opacity: 0;
    margin: 0;
    margin-left: -10px;
    bottom: 0px;
    border: 10px solid transparent;
    border-bottom-color: #aaa;
    transition: left 1s;
}

.nav-tabs > li.active:after {
    left: 50%;
    opacity: 1;
}

.nav-tabs > li[rel-index="-1"]:after {
    left: calc(50% + 100%);
}

.nav-tabs > li[rel-index="-2"]:after {
    left: calc(50% + 200%);
}

.nav-tabs > li[rel-index="-3"]:after {
    left: calc(50% + 300%);
}

.nav-tabs > li[rel-index="1"]:after {
    left: calc(50% - 100% );
}

.nav-tabs > li[rel-index="2"]:after {
    left: calc(50% - 200%);
}

.nav-tabs > li[rel-index="3"]:after {
    left: calc(50% - 300%);
}

.nav-tabs > li a {
    width: 70px;
    height: 70px;
    line-height: 70px;
    margin: 20px auto;
    border-radius: 100%;
    padding: 0;
    border: none;
    background: none;
}

.nav-tabs > li a:hover {
    border: none;
    background: none;
}

.nav-tabs > li.active a, .nav-tabs > li.active a:hover {
    border: none;
    background: none;
}

.nav-tabs > li span {
    width: 70px;
    height: 70px;
    line-height: 70px;
    display: inline-block;
    border-radius: 100%;
    background: white;
    z-index: 2;
    position: absolute;
    left: 0;
    text-align: center;
    font-size: 25px;
}

.nav-tabs > li:nth-of-type(1) span {
    color: #3e5e9a;
    border: 2px solid #3e5e9a;
}

.nav-tabs > li:nth-of-type(1).active span {
    color: #fff;
    background: #3e5e9a;
}

.nav-tabs > li:nth-of-type(2) span {
    color: #f1685e;
    border: 2px solid #f1685e;
}

.nav-tabs > li:nth-of-type(2).active span {
    color: #fff;
    background: #f1685e;
}

.nav-tabs > li:nth-of-type(3) span {
    color: #febe29;
    border: 2px solid #febe29;
}

.nav-tabs > li:nth-of-type(3).active span {
    color: #fff;
    background: #febe29;
}

.nav-tabs > li:nth-of-type(4) span {
    color: #25c225;
    border: 2px solid #25c225;
}

.nav-tabs > li:nth-of-type(4).active span {
    color: #fff;
    background: #25c225;
}

.nav-tabs > li > a.disabled {
    opacity: 1;
}

.nav-tabs > li > a.disabled span {
    border-color: #ddd;
    color: #aaa;
}

div[role="tabpanel"]:after {
    content: "";
    display: block;
    clear: both;
}

/* Begin Business Info */

#step-1 {
    background: white;
}


</style>
<script>
$(function() {
    // Nav Tab stuff
    $('.nav-tabs > li > a').hover(function() {
        if($(this).hasClass('disabled')) {
            return false;
        } else {
            var linkIndex = $(this).parent().index() - 1;
            $('.nav-tabs > li').each(function(index, item) {
                $(item).attr('rel-index', index - linkIndex);
            });
        }
    // });
    // $('#step-1-next').hover(function() {
    //     // Check values here
    //     var isValid = true;

    //     if(isValid) {
    //         $('.nav-tabs > li:nth-of-type(2) > a').removeClass('disabled').click();
    //     }
    // });
    // $('#step-2-next').hover(function() {
    //     // Check values here
    //     var isValid = true;

    //     if(isValid) {
    //         $('.nav-tabs > li:nth-of-type(3) > a').removeClass('disabled').click();
    //     }
    // });
    // $('#step-3-next').hover(function() {
    //     // Check values here
    //     var isValid = true;

    //     if(isValid) {
    //         $('.nav-tabs > li:nth-of-type(4) > a').removeClass('disabled').click();
    //     }
    // });
});


$( function() {
    $( document ).tooltip();
  } );

</script>
          
          
          <!------->
          
 <div id="footer1" style="position:fixed;bottom:0;width:100%">
            <div class="container-fluid footer-background">
                <div class="row">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-2 col-sm-3 col-xs-12 txt-center">
                                <a href="home.php">
                                    <span class="logo-text">5MEDI</span>
                                </a>
                            </div>
                            <div class="col-md-7 col-sm-6 col-xs-12">
                                <div id="footer_menu">
                                    <a href="home.php">Home</a> | 
                                    <a href="about_us.html">About Us</a> |
                                    <a href="cart.php">Shipping & Payment</a> |
                                    <a href="contact_us.html">Contact Us</a> | 
                                    <a href="tracking.php">Tracking</a><span></span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <a style="display: none" href="javascript:void(0);" class="scrollTop back-to-top" id="back-to-top">
            <i class="fa fa-chevron-up"></i>
        </a>
    </body>
</html> 
